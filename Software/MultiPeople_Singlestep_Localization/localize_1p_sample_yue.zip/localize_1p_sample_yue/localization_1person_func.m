function localization = localization_1person_func(channels, data,Fs, geophone_position, scale_min, scale_max, velocity)


% The sample frequency
dt=1/Fs;


%% illustrate the data of 4 channels
% the magnitude of showing the data
mag=2.5;

% show the four channels respectively
figure(1);
plot(data(1,:));
title('P1 center the vibration data of 8 sensors');
for i=1:channels
    subplot(channels,1,i);
    plot(data(i,:));
    set(gca,'YTick',-mag:mag:mag);
    xlabel('time /index');
ylabel('magnitude');
end
colorstring = 'rgbky';
figure(2);
title('P1 center the vibration data of 8 sensors');
for i=1:channels
    plot(data(i,:),'Color',colorstring(i));
    hold on
end





%% get the TDOA


[step_number,tdoa_pairs_all,tdoa_pairs_3channel_all,channel_3numbers_all,scale_4c_all,scale_3c_all]=...
    ShowoneScaleData_1person(channels,data,Fs,scale_min, scale_max);



%% get the localization according to the TDOA
%##########################################################################
for tdoai=1:step_number
    tdoa_pairs=tdoa_pairs_all{tdoai};
    tdoa_pairs_3channel=tdoa_pairs_3channel_all{tdoai};
    channel_3numbers=channel_3numbers_all{tdoai};
    scale_4c=scale_4c_all{tdoai};
    scale_3c=scale_3c_all{tdoai};

%% use four geophones
% The EDM of localized geophones
if (~isempty(tdoa_pairs))
D_geophone=zeros(geophone_number);
for i=1:geophone_number
    for j=1:geophone_number
        D_geophone(i,j)=norm(geophone_position(:,i)-geophone_position(:,j),2);
    end
end


num_matching=length(tdoa_pairs);
matchedposition=zeros(2,num_matching);
all_score=zeros(num_matching,1);

[matchedposition,all_score]=Echo_sorting_velocity_scale(geophone_position,D_geophone,tdoa_pairs,velocity);

% show the several good matching and remove bad ones
wrong_place=[];
for positioni=1:length(all_score)
    if(abs(matchedposition(1,positioni))>5 || abs(matchedposition(2,positioni))>5)
        wrong_place=[wrong_place,positioni];
    end
end
all_score(wrong_place)=[];
matchedposition(:,wrong_place)=[];
tdoa_pairs(wrong_place,:)=[];
scale_4c(wrong_place)=[];

% plot the localization results
figure;
plot(geophone_position(1,:),geophone_position(2,:),'r*');
hold on
t=sort(all_score);
if (length(t)>=4)
    [~,pos]=find(all_score<=t(4),4)
    plot(matchedposition(1,pos),matchedposition(2,pos),'go');
    hold on
end
plot(matchedposition(1,:),matchedposition(2,:),'bo');
else
    all_score=[];
    matchedposition=[];
    tdoa_pairs=[];
    scale_4c=[];
end

% %% save the result of 4 channels
all_score_4c=all_score;
matchedposition_4c=matchedposition;
tdoa_4c=tdoa_pairs;
all_scale_4c=scale_4c;


%% use three geophone positions
if (~isempty(tdoa_pairs_3channel))
    tdoa_pairs=tdoa_pairs_3channel;
    num_matching=length(tdoa_pairs);
    matchedposition=zeros(2,num_matching);
    all_score=zeros(num_matching,1);
for ti=1:size(tdoa_pairs,1)
geophone=channel_3numbers(ti,:);
geophone_number=3;
geophone_position_3c=[geophone_position(:,geophone(1)),geophone_position(:,geophone(2)),geophone_position(:,geophone(3))];
% The EDM of localized geophones
D_geophone=zeros(geophone_number);
for i=1:geophone_number
    for j=1:geophone_number
        D_geophone(i,j)=norm(geophone_position_3c(:,i)-geophone_position_3c(:,j),2);
    end
end

[matchedposition(:,ti),all_score(ti)]=Echo_sorting_velocity_scale(geophone_position_3c,D_geophone,tdoa_pairs(ti,:),velocity);
end
% show the several good matching
wrong_place=[];
for positioni=1:length(all_score)
    if(abs(matchedposition(1,positioni))>5 || abs(matchedposition(2,positioni))>5)
        wrong_place=[wrong_place,positioni];
    end
end

all_score(wrong_place)=[];
matchedposition(:,wrong_place)=[];
tdoa_pairs(wrong_place,:)=[];
scale_3c(wrong_place)=[];
% plot the localization results
figure;
plot(geophone_position(1,:),geophone_position(2,:),'r*');
hold on
t=sort(all_score);
if (length(t)>=4)
    [~,pos]=find(all_score<=t(4),4);
    plot(matchedposition(1,pos),matchedposition(2,pos),'go');
    hold on
end
plot(matchedposition(1,:),matchedposition(2,:),'bo');
else
    all_score=[];
    matchedposition=[];
    tdoa_pairs=[];
    scale_3c=[];
end
all_score_3c=all_score;
matchedposition_3c=matchedposition;
tdoa_3c=tdoa_pairs;
all_scale_3c=scale_3c;
%% select the best localization
[localization,scores] = Select_loc_noprior(...
                tdoa_4c,all_score_4c,matchedposition_4c,all_scale_4c,...
                tdoa_3c,all_score_3c,matchedposition_3c,all_scale_3c);
end


end

