function [step_number,tdoa_pairs,tdoa_pairs_3channel,channel_3numbers, scale_4c,scale_3c] =...
    ShowoneScaleData_1person(channels,data,Fs,scale_min,scale_max)
%% set all the varibales required for storing
tdoa_pairs={};
tdoa_pairs_3channel={};
channel_3numbers={};
scale_4c={};
scale_3c={};

% % illustrate the extraction of one event
% colorstring = 'rgbky';
% figure(4);
% for i=1:channels
%     plot(data(i,:),'Color',colorstring(i));
%     hold on
% end

    coef_all_sensors={};
    scale_length=1024;
    energy_scale=zeros(channels,scale_length); % the energy of every scale
    for i=1:channels
        isshow=0;
        [COEFS,maxscale,energy_scale(i,:)]= Getwavelet(data(i,:), isshow);
        coef_all_sensors{i}=COEFS;
    end

    [selected_scales,scales_values] = ExtractPossibleScale(channels,scale_min, scale_max,energy_scale);
    
    %% get the TDOA from reconstructed signal
    step_number=1;
    [tdoa_pairs{1},tdoa_pairs_3channel{1},channel_3numbers{1},scale_4c{1},scale_3c{1}]=GetTDOAfromSlidingWindow_normalize(coef_all_sensors,channels,scale_min,scale_max,selected_scales,Fs);

end

