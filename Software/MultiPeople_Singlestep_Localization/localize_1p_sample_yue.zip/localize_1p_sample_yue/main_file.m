% The sample frequency is 25600Hz
close all; clear all;
Fs=25600;
dt=1/Fs;



%% parameter setting &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
% load one step data
channels=4;
load('test_one_step_signals.mat');
data=one_step_data;

for i=1:channels
    data(i,:)=data(i,:)-mean(data(i,:)); % extract the mean of the data before wavelet filter
end


% geophones positions and persons positions
geophone_number=channels;
geophone_position=[3.37,0.2,3.37,0.2;3.05,2.03,1.02,0];

% set the useful scales after wavelets and velocity range
scale_min=50;
scale_max=70;
velocity=linspace(200,600,100);


% get the localization
localization = localization_1person_func(channels, data,Fs,geophone_position, scale_min, scale_max, velocity );
