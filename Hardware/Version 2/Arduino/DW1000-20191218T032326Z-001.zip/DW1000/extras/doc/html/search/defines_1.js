var searchData=
[
  ['chan_5fctrl',['CHAN_CTRL',['../DW1000_8h.html#aa62d908ff8a37c7d0685902e5e3001d2',1,'DW1000.h']]],
  ['clkpll_5fll_5fbit',['CLKPLL_LL_BIT',['../DW1000_8h.html#a98ed211b5c6d485bd017531ee77e33fe',1,'DW1000.h']]],
  ['cplock_5fbit',['CPLOCK_BIT',['../DW1000_8h.html#af9503c53f3e429808ded8a8f2abf2e8d',1,'DW1000.h']]]
];
